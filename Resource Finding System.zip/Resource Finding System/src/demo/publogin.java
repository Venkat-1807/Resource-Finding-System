package demo;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class publogin extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    Connection conn;
    Random rand=new Random();

    /**
     * Launch the application.
     * 
     */
    
    public static void sendEmail(String to, String subject, String body) {
        
        String from = "gvreddy718@gmail.com";
        final String username = "gvreddy718@gmail.com"; 
        final String password = "csms vjjx jwpp rrtn"; 
        
    
        String host = "smtp.gmail.com";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", "587");

 
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                return new javax.mail.PasswordAuthentication(username, password);
            }
        });

        try {
         
            Message message = new MimeMessage(session);

            
            message.setFrom(new InternetAddress(from));

          
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));

           
            message.setSubject(subject);

         
            message.setText(body);

      
            Transport.send(message);

            System.out.println("Sent message successfully....");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }
    
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    publogin frame = new publogin();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public publogin() {
        setBackground(new Color(32, 32, 32));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 634, 454);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(32, 32, 32));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Learning Resource finding System");
        lblNewLabel.setFont(new Font("Serif", Font.BOLD, 32));
        lblNewLabel.setForeground(new Color(255, 0, 0));
        lblNewLabel.setBounds(10, 11, 863, 55);
        contentPane.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("Username:");
        lblNewLabel_1.setForeground(new Color(255, 255, 255));
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblNewLabel_1.setBounds(29, 107, 170, 55);
        contentPane.add(lblNewLabel_1);
        
        textField = new JTextField();
        textField.setBounds(175, 121, 204, 29);
        contentPane.add(textField);
        textField.setColumns(10);
        
        JLabel lblNewLabel_2 = new JLabel("Password:");
        lblNewLabel_2.setForeground(new Color(255, 255, 255));
        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblNewLabel_2.setBounds(29, 188, 142, 29);
        contentPane.add(lblNewLabel_2);
        
        textField_1 = new JTextField();
        textField_1.setBounds(175, 188, 204, 30);
        contentPane.add(textField_1);
        textField_1.setColumns(10);
        
        JButton btnNewButton = new JButton("Login");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = textField.getText();
                String password = textField_1.getText();

                try {
                    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms_project", "root", "Saivenkat@55");

                    String query = "SELECT * FROM publisher_info WHERE username = ? AND password = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, username);
                    stmt.setString(2, password);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                    	String email=rs.getString("email");
                    	String[] otp=new String[] {Integer.toString(rand.nextInt(90000) + 10000),username};
                    	sendEmail(email,"OTP",otp[0]);
                        pubhome.main(otp);
                        dispose();
                    } else {
                        
                        JLabel lblError = new JLabel("Invalid username or password");
                        lblError.setForeground(new Color(255, 0, 0));
                        lblError.setFont(new Font("Tahoma", Font.BOLD, 14));
                        lblError.setBounds(175, 230, 300, 30);
                        contentPane.add(lblError);
                        contentPane.revalidate();
                        contentPane.repaint();
                    }

                    rs.close();
                    stmt.close();
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton.setBounds(29, 251, 156, 39);
        contentPane.add(btnNewButton);
        
        JButton btnNewButton_1 = new JButton("Register");
        btnNewButton_1.setBounds(262, 251, 142, 39);
        contentPane.add(btnNewButton_1);
        
        JButton btnNewButton_2 = new JButton("Back");
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Mainpage.main(null);
        		dispose();
        	}
        });
        btnNewButton_2.setBounds(29, 371, 89, 23);
        contentPane.add(btnNewButton_2);
    }
}
