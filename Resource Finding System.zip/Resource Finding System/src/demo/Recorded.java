package demo;

import java.awt.EventQueue;
import java.awt.Image;
import javax.swing.ImageIcon;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Recorded extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
	private JTextField textField_2;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Recorded frame = new Recorded(args[0]);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Recorded(String usr) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1077, 545);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(32, 32, 32));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel imageLabel = new JLabel("");
        imageLabel.setBounds(677, 127, 264, 226);
        ImageIcon icon = new ImageIcon("C:\\Users\\satvi\\OneDrive\\Pictures\\project venkat\\recorded.png"); // Provide path to your image
        Image img = icon.getImage().getScaledInstance(imageLabel.getWidth(), imageLabel.getHeight(), Image.SCALE_SMOOTH);
        imageLabel.setIcon(new ImageIcon(img));
        contentPane.add(imageLabel);
		
		JLabel lblNewLabel_2 = new JLabel("You can choose any one or more of them");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setBounds(10, 57, 463, 60);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_4_1 = new JLabel("TOPIC ");
		lblNewLabel_4_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_4_1.setFont(new Font("Serif", Font.PLAIN, 18));
		lblNewLabel_4_1.setBounds(10, 127, 321, 72);
		contentPane.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("Channel");
		lblNewLabel_4_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_4_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1_1.setBounds(10, 266, 321, 72);
		contentPane.add(lblNewLabel_4_1_1);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String ch=textField.getText();
				
				String topic=textField_2.getText();
				
				if(topic.equals("")) {
					topic=null;
				}
				if(ch.equals("")) {
					ch=null;
				}
				String[] send=new String[] {topic,ch,usr};
				recorded2.main(send);
				dispose();
			}
		});
		btnNewButton.setToolTipText("");
		btnNewButton.setBounds(299, 392, 200, 41);
		contentPane.add(btnNewButton);
		
		JLabel lblTitle = new JLabel("Learning Resource Finding System");
		lblTitle.setForeground(new Color(255, 69, 0));
		lblTitle.setFont(new Font("Serif", Font.BOLD, 36));
		lblTitle.setBounds(10, 10, 200, 50);
		contentPane.add(lblTitle);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(181, 137, 389, 60);
		contentPane.add(textField_2);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(181, 278, 389, 60);
		contentPane.add(textField);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] usr1=new String[] {usr};
				Home.main(usr1);
				dispose();
			}
		});
		btnNewButton_1.setBounds(10, 453, 126, 32);
		contentPane.add(btnNewButton_1);
	}
}
