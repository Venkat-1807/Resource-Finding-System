package demo;

import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class pubmain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JLabel lblNewLabel_3_4;
	private JLabel lblNewLabel_3_4_1;
	private JLabel lblNewLabel_3_4_2;
	private JLabel lblNewLabel_3_4_2_1;
	private JLabel lblNewLabel_3_4_2_1_1;
	private JLabel lblNewLabel_1;

	private Connection conn;
	private JButton btnNewButton_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pubmain frame = new pubmain(args[0]);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public pubmain(String username) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1023, 560);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(32, 32, 32));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Learning Resource Finding System");
		lblNewLabel.setForeground(new Color(255, 0, 0));
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 30));
		lblNewLabel.setBounds(213, 11, 483, 38);
		contentPane.add(lblNewLabel);

		lblNewLabel_1 = new JLabel("Total books published by You:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(590, 60, 339, 38);
		contentPane.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Fill the details below to publish a new book");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setBounds(85, 84, 383, 25);
		contentPane.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Title");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setForeground(new Color(255, 0, 0));
		lblNewLabel_3.setBounds(85, 135, 178, 25);
		contentPane.add(lblNewLabel_3);

		textField = new JTextField();
		textField.setBounds(296, 135, 234, 24);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel lblNewLabel_3_1 = new JLabel("Author");
		lblNewLabel_3_1.setForeground(Color.RED);
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3_1.setBounds(85, 191, 178, 25);
		contentPane.add(lblNewLabel_3_1);

		JLabel lblNewLabel_3_2 = new JLabel("Edition");
		lblNewLabel_3_2.setForeground(Color.RED);
		lblNewLabel_3_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3_2.setBounds(85, 237, 178, 25);
		contentPane.add(lblNewLabel_3_2);

		JLabel lblNewLabel_3_3 = new JLabel("Link");
		lblNewLabel_3_3.setForeground(Color.RED);
		lblNewLabel_3_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3_3.setBounds(85, 291, 178, 25);
		contentPane.add(lblNewLabel_3_3);

		textField_1 = new JTextField();
		textField_1.setBounds(296, 191, 234, 24);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(296, 241, 234, 24);
		contentPane.add(textField_2);

		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(296, 295, 234, 24);
		contentPane.add(textField_3);

		JButton btnNewButton = new JButton("Publish");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String title = textField.getText();
				String author = textField_1.getText();
				String editionStr = textField_2.getText();
				String link = textField_3.getText();
				boolean allFieldsFilled = true;

				if (title.isEmpty()) {
					lblNewLabel_3_4.setText("*This field is required to fill");
					allFieldsFilled = false;
				} else {
					lblNewLabel_3_4.setText("");
				}

				if (author.isEmpty()) {
					lblNewLabel_3_4_1.setText("*This field is required to fill");
					allFieldsFilled = false;
				} else {
					lblNewLabel_3_4_1.setText("");
				}

				if (editionStr.isEmpty()) {
					lblNewLabel_3_4_2.setText("*This field is required to fill");
					allFieldsFilled = false;
				} else {
					lblNewLabel_3_4_2.setText("");
				}

				if (link.isEmpty()) {
					lblNewLabel_3_4_2_1.setText("*This field is required to fill");
					allFieldsFilled = false;
				} else {
					lblNewLabel_3_4_2_1.setText("");
				}

				if (allFieldsFilled) {
					try {
						int edition = Integer.parseInt(editionStr);

						conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms_project", "root", "Saivenkat@55");

						String bookInfoQuery = "INSERT INTO book_info (Title, Author, Edition, Link) VALUES (?, ?, ?, ?)";
						PreparedStatement bookInfoStmt = conn.prepareStatement(bookInfoQuery);
						bookInfoStmt.setString(1, title);
						bookInfoStmt.setString(2, author);
						bookInfoStmt.setInt(3, edition);
						bookInfoStmt.setString(4, link);

						String bookPublisherQuery = "INSERT INTO book_publisher (Title, username) VALUES (?, ?)";
						PreparedStatement bookPublisherStmt = conn.prepareStatement(bookPublisherQuery);
						bookPublisherStmt.setString(1, title);
						bookPublisherStmt.setString(2, username);

						String publisherStatsQuery = "UPDATE publisher_stats SET publishedno = publishedno + 1 WHERE username = ?";
						PreparedStatement publisherStatsStmt = conn.prepareStatement(publisherStatsQuery);
						publisherStatsStmt.setString(1, username);

						bookInfoStmt.executeUpdate();
						bookPublisherStmt.executeUpdate();
						publisherStatsStmt.executeUpdate();

						String publishedCountQuery = "SELECT publishedno FROM publisher_stats WHERE username = ?";
						PreparedStatement publishedCountStmt = conn.prepareStatement(publishedCountQuery);
						publishedCountStmt.setString(1, username);
						ResultSet rs = publishedCountStmt.executeQuery();

						if (rs.next()) {
							int publishedNo = rs.getInt("publishedno");
							lblNewLabel_1.setText("Total books published by You: " + publishedNo);
						}

						lblNewLabel_3_4_2_1_1.setText("Book successfully published!");

					} catch (SQLException | NumberFormatException ex) {
						lblNewLabel_3_4_2_1_1.setText("Failed to Insert");
						ex.printStackTrace();
					}
				}
			}
		});
		btnNewButton.setBounds(167, 349, 118, 23);
		contentPane.add(btnNewButton);

		lblNewLabel_3_4 = new JLabel("");
		lblNewLabel_3_4.setForeground(Color.RED);
		lblNewLabel_3_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_3_4.setBounds(590, 135, 300, 25);
		contentPane.add(lblNewLabel_3_4);

		lblNewLabel_3_4_1 = new JLabel("");
		lblNewLabel_3_4_1.setForeground(Color.RED);
		lblNewLabel_3_4_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_3_4_1.setBounds(590, 191, 300, 25);
		contentPane.add(lblNewLabel_3_4_1);

		lblNewLabel_3_4_2 = new JLabel("");
		lblNewLabel_3_4_2.setForeground(Color.RED);
		lblNewLabel_3_4_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_3_4_2.setBounds(590, 244, 300, 25);
		contentPane.add(lblNewLabel_3_4_2);

		lblNewLabel_3_4_2_1 = new JLabel("");
		lblNewLabel_3_4_2_1.setForeground(Color.RED);
		lblNewLabel_3_4_2_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_3_4_2_1.setBounds(581, 295, 300, 25);
		contentPane.add(lblNewLabel_3_4_2_1);

		lblNewLabel_3_4_2_1_1 = new JLabel("");
		lblNewLabel_3_4_2_1_1.setForeground(Color.RED);
		lblNewLabel_3_4_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_3_4_2_1_1.setBounds(99, 396, 407, 25);
		contentPane.add(lblNewLabel_3_4_2_1_1);
		
		btnNewButton_1 = new JButton("Logout");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				publogin.main(null);
				dispose();
			}
		});
		btnNewButton_1.setBounds(85, 432, 89, 23);
		contentPane.add(btnNewButton_1);
	}
}
