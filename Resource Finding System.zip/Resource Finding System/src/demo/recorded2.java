package demo;

import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.Font;
import java.sql.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JSpinner;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.net.*;
import javax.swing.JComboBox;

public class recorded2 extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblTitle;
    private JTable table;
    private DefaultTableModel tableModel;
    private Connection conn;
    public String query;
    JLabel lblNewLabel_1;
    String[][] links = new String[100][1];
    int i = 0,sno=1;
    private JButton btnNewButton_1;
    private JComboBox comboBox;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    String title = args.length > 0 && args[0] != null ? args[0] : "";
                    String ch = args.length > 1 && args[1] != null ? args[1] : "";

                    recorded2 frame = new recorded2(title, ch,args[2]);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public recorded2(String title, String ch,String username) {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms_project", "root", "Saivenkat@55");

            String query = "SELECT vi.*, vr.Resourceperson " +
                    "FROM video_info vi " +
                    "INNER JOIN video_resource vr ON vi.title = vr.title AND vi.link = vr.link " +
                    "WHERE (? IS NULL OR LOWER(vi.title) LIKE LOWER(?)) AND " +
                    "(? IS NULL OR LOWER(vr.Resourceperson) LIKE LOWER(?))";

            PreparedStatement stmt = conn.prepareStatement(query);

            stmt.setString(1, title.isEmpty() ? null : title);
            stmt.setString(2, title.isEmpty() ? null : "%" + title + "%");
            stmt.setString(3, ch.isEmpty() ? null : ch);
            stmt.setString(4, ch.isEmpty() ? null : "%" + ch + "%");

            ResultSet res = stmt.executeQuery();

            setBackground(new Color(32, 32, 32));
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(100, 100, 1272, 653);
            contentPane = new JPanel();
            contentPane.setBackground(new Color(32, 32, 32));
            contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

            setContentPane(contentPane);
            contentPane.setLayout(null);

            lblTitle = new JLabel("Learning Resource Finding System");
            lblTitle.setForeground(new Color(255, 69, 0));
            lblTitle.setFont(new Font("Serif", Font.BOLD, 36));
            lblTitle.setBounds(10, 10, 1069, 50);
            contentPane.add(lblTitle);

            tableModel = new DefaultTableModel();
            tableModel.addColumn("S.no");
            tableModel.addColumn("Title");
            tableModel.addColumn("Link");
            tableModel.addColumn("Length");
            tableModel.addColumn("Resource Person");
            tableModel.addColumn("Views");

            table = new JTable(tableModel);
            table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            for (int i = 0; i < 5; i++) {
                table.getColumnModel().getColumn(i).setPreferredWidth(300);
            }
            JScrollPane scrollPane = new JScrollPane(table);
            scrollPane.setBounds(32, 74, 836, 501);
            contentPane.add(scrollPane);

            JLabel lblNewLabel = new JLabel("Set the number in the spinner for the row number to be selected and hit submit open button to open selected link");
            lblNewLabel.setForeground(new Color(255, 0, 0));
            lblNewLabel.setBounds(878, 117, 370, 37);
            contentPane.add(lblNewLabel);

            JButton btnNewButton = new JButton("Open");
            btnNewButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        int p = (int) comboBox.getSelectedItem();
                        if (p > 0 && p <= i) {
                        	String selectedLink = links[p - 1][0];
                        	String insertQuery = "INSERT INTO searchlog (username, searchedtitle, domain) VALUES (?, ?, ?)";
                            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
                            insertStmt.setString(1, username);
                            insertStmt.setString(2, table.getValueAt(p - 1, 1).toString());
                            insertStmt.setString(3, "video");
                            insertStmt.executeUpdate();
                            Desktop.getDesktop().browse(new URL(selectedLink).toURI());
                            
                        } else {
                            lblNewLabel_1.setText("Set proper value in the spinner");
                        }
                    } catch (IOException | URISyntaxException  | SQLException e1) {
                        e1.printStackTrace();
                    }

                }
            });
            btnNewButton.setBounds(947, 165, 200, 37);
            contentPane.add(btnNewButton);

            lblNewLabel_1 = new JLabel("");
            lblNewLabel_1.setForeground(new Color(255, 0, 0));
            lblNewLabel_1.setBounds(878, 260, 370, 50);
            contentPane.add(lblNewLabel_1);

            btnNewButton_1 = new JButton("Back");
            btnNewButton_1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	String[] usr=new String[]{username};
                    Recorded.main(usr);
                    dispose();
                }
            });
            btnNewButton_1.setBounds(32, 586, 127, 23);
            contentPane.add(btnNewButton_1);
            
            comboBox = new JComboBox();
            comboBox.setBounds(994, 213, 85, 22);
            contentPane.add(comboBox);

            while (res.next()) {
                String[] rowdata = new String[6];
                rowdata[0]=Integer.toString(sno);
                rowdata[1] = res.getString("Title");
                rowdata[2] = res.getString("Link");
                rowdata[3] = res.getTime("Length").toString();
                rowdata[4] = res.getString("Resourceperson");
                rowdata[5] = Integer.toString(res.getInt("views"));
                links[i][0] = res.getString("Link");
                System.out.println(links[i][0]);
                i++;
                comboBox.addItem(sno);
                sno++;
                tableModel.addRow(rowdata);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
