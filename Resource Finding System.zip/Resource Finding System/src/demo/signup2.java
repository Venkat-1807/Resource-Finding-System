package demo;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class signup2 extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    JLabel lblNewLabel_2;
    private Connection conn;
    String query="INSERT INTO user_info(username,name,age) VALUES(?,?,?)";
    String queryAuth="INSERT INTO user_auth(username,password) VALUES(?,?)";
    int i=0;
    int rowsInserted;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    signup2 frame = new signup2(args[0],args[1],args[2],args[3],args[4],Integer.parseInt(args[5]));
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public signup2(String otp,String username,String name,String password,String emailid,int age) {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms_project", "root", "Saivenkat@55");
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            PreparedStatement preparedStatementAuth = conn.prepareStatement(queryAuth);

            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(100, 100, 716, 495);
            contentPane = new JPanel();
            contentPane.setBackground(new Color(32, 32, 32));
            contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
            setContentPane(contentPane);
            contentPane.setLayout(null);

            JLabel lblNewLabel_1 = new JLabel("Learning Resource Finding System");
            lblNewLabel_1.setForeground(new Color(255, 0, 0));
            lblNewLabel_1.setBounds(10, 10, 564, 37);
            lblNewLabel_1.setFont(new Font("Tahoma", Font.ITALIC, 30));
            contentPane.add(lblNewLabel_1);

            JLabel lblNewLabel = new JLabel("Enter OTP");
            lblNewLabel.setForeground(new Color(0, 255, 0));
            lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
            lblNewLabel.setBounds(101, 135, 82, 52);
            contentPane.add(lblNewLabel);

            textField = new JTextField();
            textField.setBounds(193, 151, 213, 28);
            contentPane.add(textField);
            textField.setColumns(10);

            JButton btnNewButton = new JButton("Submit");
            btnNewButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String s=textField.getText();
                    if(s.equals(otp)) {
                        try {
                            preparedStatement.setString(1,username);
                            preparedStatement.setString(2,name);
                            preparedStatement.setInt(3,age);
                            preparedStatementAuth.setString(1,username);
                            preparedStatementAuth.setString(2,password);
                            
                            rowsInserted = preparedStatement.executeUpdate();
                            rowsInserted += preparedStatementAuth.executeUpdate();

                        } catch (SQLException e1) {
                            e1.printStackTrace();
                        }
                        if(rowsInserted > 0) {
                            lblNewLabel_2.setText("Account Created Successfully, Click on Next to go to homepage");
                            i=1;
                        }
                        else {
                            lblNewLabel_2.setText("An Internal Error has occurred");
                        }
                    }
                    else {
                        lblNewLabel_2.setText("Incorrect OTP has been entered");
                    }
                }
            });
            btnNewButton.setBounds(193, 216, 97, 28);
            contentPane.add(btnNewButton);

            lblNewLabel_2 = new JLabel("");
            lblNewLabel_2.setForeground(new Color(255, 0, 0));
            lblNewLabel_2.setBounds(101, 255, 488, 28);
            contentPane.add(lblNewLabel_2);

            JButton btnNewButton_1 = new JButton("Next");
            btnNewButton_1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if(i==1) {
                        Mainpage.main(null);
                        dispose();
                    }
                    else {
                        lblNewLabel_2.setText("Enter Correct OTP and Submit");
                    }

                }
            });
            btnNewButton_1.setBounds(300, 215, 106, 31);
            contentPane.add(btnNewButton_1);
        }
        catch(SQLException e) {
            e.printStackTrace();
        }
    }
}
