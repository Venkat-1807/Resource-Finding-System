package demo;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.Color;
import java.awt.Image;
import java.awt.Dimension;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Mainpage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private String query="SELECT password FROM user_auth WHERE username=?";
    private JPasswordField passwordField;
    private String username,password;
    char[] pass;
    String passw;
    int p=0;
    JLabel lblNewLabel;
    private Connection conn;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Mainpage frame = new Mainpage();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Mainpage() {
    	try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms_project", "root", "Saivenkat@55");
            Statement statement = conn.createStatement();
            PreparedStatement preparedStatement = conn.prepareStatement(query);
		
        setAlwaysOnTop(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 867, 489);
        
        contentPane = new JPanel();
        contentPane.setBackground(new Color(32, 32, 32));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        // Adding labels, text fields, and buttons
        JLabel lblNewLabel_1 = new JLabel("ENTER YOUR USERNAME :");
        lblNewLabel_1.setBounds(24, 143, 257, 28);
        lblNewLabel_1.setForeground(new Color(255, 255, 255));
        lblNewLabel_1.setBackground(new Color(255, 255, 255));
        lblNewLabel_1.setFont(new Font("Serif", Font.BOLD, 18));
        contentPane.add(lblNewLabel_1);

        textField = new JTextField();
        textField.setBounds(312, 151, 159, 19);
        textField.setBackground(new Color(255, 255, 255));
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("ENTER YOUR PASSWORD :");
        lblNewLabel_2.setBounds(24, 203, 257, 19);
        lblNewLabel_2.setForeground(new Color(255, 255, 255));
        lblNewLabel_2.setBackground(new Color(255, 255, 255));
        lblNewLabel_2.setFont(new Font("Serif", Font.BOLD, 18));
        contentPane.add(lblNewLabel_2);

        JButton btnNewButton = new JButton("Submit");
        btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				username=textField.getText();
				pass=passwordField.getPassword();
				String passw=new String(pass);
				try {
					preparedStatement.setString(1, username);
					try (ResultSet resultSet = preparedStatement.executeQuery()) {
						if (resultSet.next()) {
							password=resultSet.getString("password");
							
						}
						else {
							p=1;
						}
					}
				}
				catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				if(p==0) {
					if(passw.equals(password)) {
						String[] send=new String[] {username};
						Home.main(send);
						dispose();
					}
					else {
						lblNewLabel.setText("Incorrect Password");
					}
				}
				else {
					lblNewLabel.setText("User Doesnt Exist..Create an Account");
					p=0;
				}
				
			}
        });
        btnNewButton.setBackground(new Color(255, 69, 0));
        btnNewButton.setBounds(91, 281, 150, 50);
        btnNewButton.setForeground(new Color(255, 255, 255));
        btnNewButton.addActionListener(e -> {
            // Add action here
        });
        btnNewButton.setFont(new Font("Serif", Font.BOLD, 18));
        contentPane.add(btnNewButton);
        
        JLabel lblTitle = new JLabel("Learning Resource Finding System");
        lblTitle.setBounds(10, 10, 833, 50);
        lblTitle.setForeground(new Color(255, 69, 0));
        lblTitle.setFont(new Font("Serif", Font.BOLD, 36));
        contentPane.add(lblTitle);
        
        JButton btnSignup = new JButton("Signup");
        btnSignup.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		signuppage.main(null);
        		dispose();
        	}
        });
        btnSignup.setBounds(312, 281, 150, 50);
        btnSignup.setForeground(Color.WHITE);
        btnSignup.setFont(new Font("Serif", Font.BOLD, 18));
        btnSignup.setBackground(new Color(255, 69, 0));
        contentPane.add(btnSignup);
        
        passwordField = new JPasswordField();
        passwordField.setBounds(312, 205, 159, 20);
        contentPane.add(passwordField);
        
        lblNewLabel = new JLabel("");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel.setForeground(new Color(255, 0, 0));
        lblNewLabel.setBounds(208, 357, 254, 33);
        contentPane.add(lblNewLabel);
        
        JButton btnSignup_1 = new JButton("Publisher");
        btnSignup_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		publogin.main(null);
        		dispose();
        	}
        });
        btnSignup_1.setForeground(Color.WHITE);
        btnSignup_1.setFont(new Font("Serif", Font.BOLD, 18));
        btnSignup_1.setBackground(new Color(255, 69, 0));
        btnSignup_1.setBounds(533, 281, 150, 50);
        contentPane.add(btnSignup_1);
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
}
