package demo;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

public class Home extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    Connection conn;
    String query1;
    
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Home frame = new Home(args[0]);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Home(String username) {
    	String[] us= new String[]{username};
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms_project", "root", "Saivenkat@55");
            query1="SELECT name FROM user_info WHERE username=?";
            PreparedStatement stmt = conn.prepareStatement(query1);
            stmt.setString(1, username);
            ResultSet res = stmt.executeQuery();
            if(res.next()) {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(100, 100, 760, 430);
            contentPane = new JPanel();
            contentPane.setBackground(new Color(32, 32, 32));
            contentPane.setForeground(new Color(255, 255, 255));
            contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

            setContentPane(contentPane);
            contentPane.setLayout(null);

            JLabel lblNewLabel_1 = new JLabel("Welcome"+res.getString("name")+" What would you like to do Today");
            lblNewLabel_1.setForeground(new Color(255, 69, 0));
            lblNewLabel_1.setBounds(20, 83, 444, 28);
            lblNewLabel_1.setFont(new Font("MV Boli", Font.ITALIC, 20));
            contentPane.add(lblNewLabel_1);

            JLabel lblNewLabel_4 = new JLabel("");
            lblNewLabel_4.setBounds(10, 121, 429, 70);
            lblNewLabel_4.setFont(new Font("Tahoma", Font.ITALIC, 24));
            contentPane.add(lblNewLabel_4);

            JButton btnNewButton = new JButton("Explore videos");
            btnNewButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Recorded.main(us);
                    dispose();
                }
            });
            btnNewButton.setBackground(Color.ORANGE);
            btnNewButton.setBounds(41, 184, 233, 55);
            btnNewButton.setFont(new Font("Tw Cen MT", Font.ITALIC, 18));
            contentPane.add(btnNewButton);

            JButton btnBooks = new JButton("Explore Books");
            btnBooks.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    book.main(us);
                    dispose();
                }
            });
            btnBooks.setBackground(Color.ORANGE);
            btnBooks.setBounds(397, 184, 233, 55);
            btnBooks.setFont(new Font("Tw Cen MT", Font.ITALIC, 18));
            contentPane.add(btnBooks);

            JLabel lblTitle = new JLabel("Learning Resourcr Finding System");
            lblTitle.setForeground(new Color(255, 69, 0));
            lblTitle.setFont(new Font("Serif", Font.BOLD, 36));
            lblTitle.setBounds(10, 10, 709, 50);
            contentPane.add(lblTitle);

            JButton btnNewButton_1 = new JButton("Back");
            btnNewButton_1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Mainpage.main(null);
                }
            });
            btnNewButton_1.setBounds(10, 339, 132, 28);
            contentPane.add(btnNewButton_1);

            JButton btnNewButton_2 = new JButton("History");
            btnNewButton_2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        
                        JFrame historyFrame = new JFrame("Search History");
                        historyFrame.setBounds(100, 100, 600, 400);
                        JPanel historyPanel = new JPanel();
                        historyPanel.setLayout(new BorderLayout());
                        historyFrame.setContentPane(historyPanel);

                       
                        String query = "SELECT * FROM searchlog WHERE username = ?";
                        PreparedStatement stmt = conn.prepareStatement(query);
                        stmt.setString(1, username);
                        ResultSet rs = stmt.executeQuery();

                        
                        JTable historyTable = new JTable(buildTableModel(rs));
                        JScrollPane scrollPane = new JScrollPane(historyTable);
                        historyPanel.add(scrollPane, BorderLayout.CENTER);

                        
                        historyFrame.setVisible(true);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            });
            btnNewButton_2.setBounds(563, 339, 112, 28);
            contentPane.add(btnNewButton_2);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public static DefaultTableModel buildTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();

       
        int columnCount = metaData.getColumnCount();
        Vector<String> columnNames = new Vector<String>();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }

        
        Vector<Vector<Object>> data = new Vector<Vector<Object>>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<Object>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }

        return new DefaultTableModel(data, columnNames);
    }
}
