package demo;

import java.awt.EventQueue;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.JScrollBar;
import javax.swing.JMenuBar;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JDesktopPane;
import java.awt.Color;
import java.util.Random;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import javax.swing.JProgressBar;

public class signuppage extends JFrame {
	
	private Connection conn;
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private String name,password,confirmpassword,email,age;
	private String username;
	JLabel lblNewLabel_5;
	JLabel lblNewLabel_6;
	String query = "SELECT username FROM user_info WHERE username = ?";
	Random rand=new Random();
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_9;
	int t=0;

	/**
	 * Launch the application.
	 */
	
	
	public static void sendEmail(String to, String subject, String body) {
      
        String from = "gvreddy718@gmail.com";
        final String username = "gvreddy718@gmail.com"; 
        final String password = "csms vjjx jwpp rrtn"; 
        
    
        String host = "smtp.gmail.com";

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", "587");

 
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
                return new javax.mail.PasswordAuthentication(username, password);
            }
        });

        try {
         
            Message message = new MimeMessage(session);

            
            message.setFrom(new InternetAddress(from));

          
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));

           
            message.setSubject(subject);

         
            message.setText(body);

      
            Transport.send(message);

            System.out.println("Sent message successfully....");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					signuppage frame = new signuppage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void cleartext() {
		textField.setText("");
		textField_1.setText("");
		textField_2.setText("");
		textField_3.setText("");
		textField_4.setText("");
		textField_5.setText("");
	}
	public signuppage() {
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms_project", "root", "Saivenkat@55");
            Statement statement = conn.createStatement();
            PreparedStatement preparedStatement = conn.prepareStatement(query);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1539, 670);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(32, 32, 32));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Learning Resource Finnding System");
		lblNewLabel.setForeground(new Color(255, 0, 0));
		lblNewLabel.setBounds(445, 11, 479, 50);
		lblNewLabel.setFont(new Font("Tahoma", Font.ITALIC, 30));
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Enter your Name :");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(478, 90, 200, 28);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Enter Username :");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setBounds(478, 115, 200, 28);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Enter you Pasword :");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setBounds(478, 147, 200, 28);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Confirm Password : ");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setBounds(478, 183, 200, 28);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("Enter your Email id :");
		lblNewLabel_4_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_4_1.setBounds(478, 222, 200, 28);
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("Enter your age :");
		lblNewLabel_4_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_4_2.setBounds(478, 261, 200, 28);
		lblNewLabel_4_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		contentPane.add(lblNewLabel_4_2);
		
		JButton btnNewButton_1 = new JButton("Submit");
		btnNewButton_1.setBounds(595, 326, 130, 21);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				name=textField.getText();
				username=textField_1.getText();
				password=textField_2.getText();
				confirmpassword=textField_3.getText();
				email=textField_4.getText();
				age=textField_5.getText();
				lblNewLabel_5.setText("");
				lblNewLabel_6.setText("");
				lblNewLabel_7.setText("");
				lblNewLabel_8.setText("");
				lblNewLabel_9.setText("");
				try {
					preparedStatement.setString(1, username);
					ResultSet resultSet = preparedStatement.executeQuery();
					if(resultSet.next()) {
						t=1;
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if(!password.equals(confirmpassword)) {
					lblNewLabel_5.setText("The Password confirmation Doesnt match");
				}
				else if(password.equals("")) {
					lblNewLabel_5.setText("*This field cannot be empty");
				}
				else if(!email.contains("@gmail.com")) {
					lblNewLabel_6.setText("Enter a valid E-Mail");
				}
				
				else if(password.length()<8) {
					lblNewLabel_5.setText("The length of password should be greater than 8 charcters");
				}
				else if(age.equals("")) {
					lblNewLabel_7.setText("*This field cannot be empty");
				}
				else if(name.equals("")) {
					lblNewLabel_8.setText("*This field cannot be empty");
				}
				else if(username.equals("")) {
					lblNewLabel_9.setText("*This field cannot be empty");
				}
				else if(t==1) {
					lblNewLabel_9.setText("*This username is already taken");
					t=0;
				}
				else {
					int otp=rand.nextInt(90000) + 10000;
					String s[]=new String[] {String.valueOf(otp),username,name,password,email,age};
					sendEmail(email,"OTP",String.valueOf(otp));
					signup2.main(s);
					dispose();
				}
				cleartext();
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		contentPane.add(btnNewButton_1);
		
		textField = new JTextField();
		textField.setBounds(667, 96, 215, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(667, 121, 215, 19);
		textField_1.setColumns(10);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(667, 153, 215, 19);
		textField_2.setColumns(10);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setBounds(667, 189, 215, 19);
		textField_3.setColumns(10);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setBounds(667, 228, 215, 19);
		textField_4.setColumns(10);
		contentPane.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setBounds(667, 267, 215, 19);
		textField_5.setColumns(10);
		contentPane.add(textField_5);
		
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(104, 374, 1, 1);
		contentPane.add(desktopPane);
		
		lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setForeground(new Color(255, 0, 0));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(892, 183, 391, 31);
		contentPane.add(lblNewLabel_5);
		
		lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setForeground(new Color(255, 0, 0));
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setBounds(902, 222, 334, 28);
		contentPane.add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_7.setForeground(new Color(255, 0, 0));
		lblNewLabel_7.setBounds(912, 261, 324, 28);
		contentPane.add(lblNewLabel_7);
		
		lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_8.setForeground(new Color(255, 0, 0));
		lblNewLabel_8.setBounds(902, 90, 312, 30);
		contentPane.add(lblNewLabel_8);
		
		lblNewLabel_9 = new JLabel("");
		lblNewLabel_9.setForeground(new Color(255, 0, 0));
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_9.setBounds(902, 124, 312, 28);
		contentPane.add(lblNewLabel_9);
		
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
