package demo;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.net.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JSpinner;
import javax.swing.JList;
import javax.swing.JComboBox;

public class books2 extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblTitle;
    private DefaultTableModel tableModel;
    private JTable table;
    JLabel lblNewLabel_1;
    private Connection conn;
    JComboBox comboBox;
    String[][] links = new String[100][1];
    int i = 0,sno=0;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    String title = args.length > 0 ? args[0] : null;
                    String auth = args.length > 1 ? args[1] : null;
                    String publi = args.length > 2 ? args[2] : null;
                    books2 frame = new books2(title, auth, publi,args[3]);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public books2(String title, String auth, String publi,String username) {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms_project", "root", "Saivenkat@55");

            String query = "SELECT bi.*, pi.name AS Publisher " +
                    "FROM book_info bi " +
                    "INNER JOIN book_publisher bp ON bi.Title = bp.Title " +
                    "INNER JOIN publisher_info pi ON bp.username = pi.username " +
                    "WHERE (? IS NULL OR LOWER(bi.Title) LIKE LOWER(?)) AND " +
                    "(? IS NULL OR LOWER(bi.Author) LIKE LOWER(?)) AND " +
                    "(? IS NULL OR LOWER(pi.name) LIKE LOWER(?))";

            
            PreparedStatement stmt = conn.prepareStatement(query);

            stmt.setString(1, title);
            stmt.setString(2, title != null ? "%" + title + "%" : null);
            stmt.setString(3, auth);
            stmt.setString(4, auth != null ? "%" + auth + "%" : null);
            stmt.setString(5, publi);
            stmt.setString(6, publi != null ? "%" + publi + "%" : null);

            ResultSet res = stmt.executeQuery();

            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(100, 100, 1428, 711);
            contentPane = new JPanel();
            contentPane.setBackground(new Color(32, 32, 32));
            contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

            setContentPane(contentPane);
            contentPane.setLayout(null);

            lblTitle = new JLabel("Learning Resource Finding System");
            lblTitle.setForeground(new Color(255, 69, 0));
            lblTitle.setFont(new Font("Serif", Font.BOLD, 36));
            lblTitle.setBounds(67, 10, 978, 50);
            contentPane.add(lblTitle);

            tableModel = new DefaultTableModel();
            tableModel.addColumn("S.no");
            tableModel.addColumn("Title");
            tableModel.addColumn("Author");
            tableModel.addColumn("Publisher");
            tableModel.addColumn("Edition");
            tableModel.addColumn("Link");

            table = new JTable(tableModel);
            table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            for (int i = 0; i < 5; i++) {
                table.getColumnModel().getColumn(i).setPreferredWidth(200);
            }
            JScrollPane scrollPane = new JScrollPane(table);
            scrollPane.setBounds(25, 76, 998, 543);
            contentPane.add(scrollPane);
            
            JLabel lblNewLabel = new JLabel("Set the number in the spinner for the row number to be selected and hit submit open button to open selected link");
            lblNewLabel.setForeground(new Color(255, 0, 0));
            lblNewLabel.setBounds(1033, 76, 417, 93);
            contentPane.add(lblNewLabel);
            
            JButton btnNewButton = new JButton("Open Link");
            btnNewButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        
                        if(sno>=1) {
                            int p = (int) comboBox.getSelectedItem();
                            if (p > 0 && p <= i ) {
                                String selectedLink = links[p - 1][0];
                                Desktop.getDesktop().browse(new URL(selectedLink).toURI());
                                
                                
                                String insertQuery = "INSERT INTO searchlog (username, searchedtitle, domain) VALUES (?, ?, ?)";
                                PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
                                insertStmt.setString(1, username);
                                insertStmt.setString(2, table.getValueAt(p - 1, 1).toString());
                                insertStmt.setString(3, "book");
                                insertStmt.executeUpdate();
                            } else {
                                lblNewLabel_1.setText("Set proper value in the comboBox");
                            }
                        }
                        else {
                            lblNewLabel_1.setText("No Result Found");
                        }
                    } catch (IOException | URISyntaxException | SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            });
            btnNewButton.setBounds(1033, 194, 240, 37);
            contentPane.add(btnNewButton);
            
            lblNewLabel_1 = new JLabel("");
            lblNewLabel_1.setForeground(new Color(255, 0, 0));
            lblNewLabel_1.setBounds(1033, 299, 240, 50);
            contentPane.add(lblNewLabel_1);
            
            JButton btnNewButton_1 = new JButton("BACK");
            btnNewButton_1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	String usr[]=new String[] {username};
                    book.main(usr);
                    dispose();
                }
            });
            btnNewButton_1.setBounds(52, 630, 162, 33);
            contentPane.add(btnNewButton_1);
            
            comboBox = new JComboBox();
            comboBox.setBounds(1082, 253, 127, 22);
            contentPane.add(comboBox);
            
            JButton btnNewButton_2 = new JButton("About Author");
            btnNewButton_2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    try {
                        if(sno>0) {
                            int selectedIndex = comboBox.getSelectedIndex();
                            
                            String title = (String) table.getValueAt(selectedIndex , 1); // Assuming the title is in the 2nd column
                            
                            String query = "SELECT * FROM author_basic AS ab " +
                                           "JOIN author_qualification AS aq ON ab.Name = aq.Name " +
                                           "JOIN author_writings AS aw ON ab.Name = aw.Name " +
                                           "WHERE ab.Name = (SELECT Author FROM book_info WHERE Title = ?)";
                            PreparedStatement stmt = conn.prepareStatement(query);
                            stmt.setString(1, title);

                            ResultSet res = stmt.executeQuery();

                             StringBuilder authorDetails = new StringBuilder();
                            if (res.next()) {
                                authorDetails.append("Name: ").append(res.getString("Name")).append("\n");
                                authorDetails.append("Date of Birth: ").append(res.getString("DOB")).append("\n");
                                authorDetails.append("Qualification: ").append(res.getString("qualification")).append("\n");
                                authorDetails.append("Number of Writings: ").append(res.getInt("NoWritten")).append("\n");
                                
                            }

                            javax.swing.JOptionPane.showMessageDialog(null, authorDetails.toString(), "Author Details", javax.swing.JOptionPane.INFORMATION_MESSAGE);
                        
                        } 
                    }
                    catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            });
            btnNewButton_2.setBounds(1033, 160, 240, 23);
            contentPane.add(btnNewButton_2);
            
            while (res.next()) {
                String[] rowdata = new String[6];
                rowdata[0]=Integer.toString(++sno);
                rowdata[1] = res.getString("Title");
                rowdata[2] = res.getString("Author");
                rowdata[3] = res.getString("Publisher");
                rowdata[4] = Integer.toString(res.getInt("Edition"));
                rowdata[5] = res.getString("link");
                links[i][0] = res.getString("link");
                i++;
                comboBox.addItem(sno);
                
                tableModel.addRow(rowdata);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
